create function st_askml(text) returns text
    immutable
    strict
    parallel safe
    cost 250
    language sql
as
$$ SELECT public.ST_AsKML($1::public.geometry, 15);  $$;

alter function st_askml(text) owner to "user";

